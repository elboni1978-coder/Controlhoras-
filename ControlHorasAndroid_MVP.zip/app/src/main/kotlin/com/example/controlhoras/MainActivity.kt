package com.example.controlhoras

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Image
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.text.DecimalFormat
import kotlin.math.max

data class ShiftRow(
    val day: String,
    val entry: String,
    val exit: String
)

class MainActivity : ComponentActivity() {
    private val recognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                TimeCardApp(
                    onScan = { bitmap, onDone ->
                        recognizeCard(bitmap, onDone)
                    }
                )
            }
        }
    }

    private fun recognizeCard(bitmap: Bitmap, onDone: (List<ShiftRow>) -> Unit) {
        val image = InputImage.fromBitmap(bitmap, 0)
        recognizer.process(image)
            .addOnSuccessListener { result ->
                onDone(TimeCardParser.parse(result.text))
            }
            .addOnFailureListener {
                onDone(emptyList())
            }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TimeCardApp(
    onScan: (Bitmap, (List<ShiftRow>) -> Unit) -> Unit
) {
    var rows by remember { mutableStateOf(listOf<ShiftRow>()) }
    var hourlyRate by remember { mutableStateOf("20") }
    var processing by remember { mutableStateOf(false) }
    var showManual by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    val context = androidx.compose.ui.platform.LocalContext.current

    val cameraLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.TakePicturePreview()
    ) { bitmap ->
        if (bitmap != null) {
            processing = true
            error = ""
            onScan(bitmap) { detected ->
                processing = false
                if (detected.isEmpty()) {
                    error = "No pude reconocer horarios. Puedes agregarlos manualmente."
                    showManual = true
                } else {
                    rows = detected
                }
            }
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) cameraLauncher.launch(null)
        else error = "Se necesita permiso de cámara para escanear la tarjeta."
    }

    val galleryLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            // Gallery OCR can be added in the same way using InputImage.fromFilePath.
            error = "La versión inicial usa la cámara. La opción de galería queda preparada para la siguiente versión."
        }
    }

    val totalMinutes = rows.sumOf { minutesBetween(it.entry, it.exit) }
    val totalPay = totalMinutes / 60.0 * (hourlyRate.toDoubleOrNull() ?: 0.0)
    val money = DecimalFormat("#,##0.00").format(totalPay)

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Control de Horas") })
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text(
                    "Escanea una tarjeta y revisa las horas antes de calcular el pago.",
                    style = MaterialTheme.typography.bodyLarge
                )
            }

            item {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = {
                            val permission = Manifest.permission.CAMERA
                            if (ContextCompat.checkSelfPermission(
                                    context,
                                    permission
                                ) == PackageManager.PERMISSION_GRANTED
                            ) {
                                cameraLauncher.launch(null)
                            } else {
                                permissionLauncher.launch(permission)
                            }
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.CameraAlt, null)
                        Spacer(Modifier.width(6.dp))
                        Text("Tomar foto")
                    }

                    OutlinedButton(
                        onClick = { showManual = true },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Edit, null)
                        Spacer(Modifier.width(6.dp))
                        Text("Editar")
                    }
                }
            }

            item {
                OutlinedButton(
                    onClick = { galleryLauncher.launch("image/*") },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Image, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Elegir foto")
                }
            }

            item {
                OutlinedTextField(
                    value = hourlyRate,
                    onValueChange = { hourlyRate = it },
                    label = { Text("Pago por hora") },
                    prefix = { Text("$ ") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            if (processing) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp))
                        Spacer(Modifier.width(10.dp))
                        Text("Leyendo la tarjeta...")
                    }
                }
            }

            if (error.isNotEmpty()) {
                item {
                    Text(error, color = MaterialTheme.colorScheme.error)
                }
            }

            item {
                Text("Horarios detectados", style = MaterialTheme.typography.titleLarge)
            }

            itemsIndexed(rows) { index, row ->
                ShiftCard(
                    row = row,
                    onChange = { updated ->
                        rows = rows.toMutableList().also { it[index] = updated }
                    }
                )
            }

            if (rows.isEmpty()) {
                item {
                    Text("Todavía no hay horarios. Toma una foto de la tarjeta.")
                }
            }

            item {
                HorizontalDivider()
                Text("Total de horas", style = MaterialTheme.typography.titleMedium)
                Text(
                    formatMinutes(totalMinutes),
                    style = MaterialTheme.typography.headlineSmall
                )
                Spacer(Modifier.height(4.dp))
                Text("Total a pagar", style = MaterialTheme.typography.titleMedium)
                Text(
                    "$$money",
                    style = MaterialTheme.typography.headlineLarge
                )
            }
        }
    }

    if (showManual) {
        ManualRowsDialog(
            initial = rows,
            onDismiss = { showManual = false },
            onSave = {
                rows = it
                showManual = false
            }
        )
    }
}

@Composable
fun ShiftCard(row: ShiftRow, onChange: (ShiftRow) -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Text("Día ${row.day}", style = MaterialTheme.typography.titleMedium)
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = row.entry,
                    onValueChange = { onChange(row.copy(entry = it)) },
                    label = { Text("Entrada") },
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = row.exit,
                    onValueChange = { onChange(row.copy(exit = it)) },
                    label = { Text("Salida") },
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
fun ManualRowsDialog(
    initial: List<ShiftRow>,
    onDismiss: () -> Unit,
    onSave: (List<ShiftRow>) -> Unit
) {
    var text by remember {
        mutableStateOf(
            initial.joinToString("\n") { "${it.day},${it.entry},${it.exit}" }
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Editar horarios") },
        text = {
            Column {
                Text("Una fila por día: día,entrada,salida")
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    minLines = 5,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(onClick = {
                val parsed = text.lines().mapNotNull { line ->
                    val p = line.split(",").map { it.trim() }
                    if (p.size >= 3) ShiftRow(p[0], p[1], p[2]) else null
                }
                onSave(parsed)
            }) { Text("Guardar") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar") }
        }
    )
}

object TimeCardParser {
    private val timeRegex = Regex("""(?<!\d)(\d{1,2})\s*[:.]\s*(\d{2})(?:\s*([APap][Mm]))?(?!\d)""")

    fun parse(text: String): List<ShiftRow> {
        val lines = text.lines()
        val output = mutableListOf<ShiftRow>()
        var fallbackDay = 1

        for (line in lines) {
            val times = timeRegex.findAll(line).map { match ->
                val h = match.groupValues[1].toIntOrNull() ?: 0
                val m = match.groupValues[2].toIntOrNull() ?: 0
                val ampm = match.groupValues.getOrNull(3)?.uppercase() ?: ""
                normalizeTime(h, m, ampm)
            }.toList()

            if (times.size >= 2) {
                val day = Regex("""^\s*(\d{1,2})\b""").find(line)?.groupValues?.get(1)
                    ?: fallbackDay.toString()
                output += ShiftRow(day, times[0], times[1])
                fallbackDay++
            }
        }

        return output
    }

    private fun normalizeTime(hour: Int, minute: Int, ampm: String): String {
        if (hour !in 0..23 || minute !in 0..59) return ""
        val h = if (hour == 0) 12 else hour
        return "%d:%02d%s".format(h, minute, ampm)
    }
}

fun minutesBetween(entry: String, exit: String): Int {
    val a = parseMinutes(entry)
    val b = parseMinutes(exit)
    if (a == null || b == null) return 0
    var diff = b - a
    if (diff < 0) diff += 24 * 60
    return diff
}

fun parseMinutes(value: String): Int? {
    val m = Regex("""^\s*(\d{1,2})[:.](\d{2})\s*([APap][Mm])?\s*$""").find(value) ?: return null
    var h = m.groupValues[1].toIntOrNull() ?: return null
    val min = m.groupValues[2].toIntOrNull() ?: return null
    if (min !in 0..59) return null
    val ap = m.groupValues[3].uppercase()
    if (ap == "AM" && h == 12) h = 0
    if (ap == "PM" && h < 12) h += 12
    if (h !in 0..23) return null
    return h * 60 + min
}

fun formatMinutes(minutes: Int): String {
    return "${minutes / 60} h ${minutes % 60} min"
}

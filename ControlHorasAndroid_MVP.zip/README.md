# Control de Horas — Android

Prototipo inicial para leer una tarjeta de horario mediante la cámara, detectar pares entrada/salida y calcular el pago por hora.

## Funciones incluidas

- Cámara del teléfono.
- OCR con Google ML Kit.
- Reconocimiento básico de horarios.
- Edición manual de las filas.
- Tarifa configurable (por defecto $20/h).
- Cálculo de horas y pago total.
- Compatible con tarjetas donde cada fila representa un día y hay entrada/salida.

## Abrir

1. Instala Android Studio.
2. Abre esta carpeta como proyecto.
3. Deja que Gradle descargue las dependencias.
4. Conecta un teléfono Android o usa un emulador.
5. Ejecuta `app`.

## Importante

Este es un MVP. El OCR todavía necesita una segunda fase especializada para este formato de tarjeta: detectar la cuadrícula, asociar cada número a su fila/columna y mostrar una confianza por cada lectura. Eso permitirá que una tarjeta borrosa no produzca pagos incorrectos.
